<?php

function mdta_preprocess_node(&$vars) {
  // Add JS & CSS by node ID
	$matches = "content/traffic-cameras";
	$path = drupal_get_path_alias($_GET['q']);
	$page_match = drupal_match_path($path, $matches);
	if ( $page_match ) {
		drupal_add_js( 'https://maps.googleapis.com/maps/api/js?v=3&key=AIzaSyBJGXgH95LYqdcZGdZruM8U1c6v_6yBw2I' );
		drupal_add_js( path_to_theme().'/js/traffic-cams-noflash-mdta.js' );
	}
}

function mdta_date_nav_title($params) {
	$params['format'] = ($params['granularity']=='month') ? 'F Y' : $params['format'];
	$output = theme_date_nav_title($params);
	return $output;
}

function mdta_form_search_block_form_alter(&$form, &$form_state, $form_id) {
    $form['search_block_form']['#title'] = t('Search'); // Change the text on the label element
	 $form['search_block_form']['#title_display'] = 'invisible'; // Toggle label visibilty
    $form['search_block_form']['#default_value'] = t('Search'); // Set a default value for the textfield

    // Add extra attributes to the text box
    $form['search_block_form']['#attributes']['onblur'] = "if (this.value == '') {this.value = 'Search';}";
    $form['search_block_form']['#attributes']['onfocus'] = "if (this.value == 'Search') {this.value = '';}";
    // Prevent user from searching the default text
    $form['#attributes']['onsubmit'] = "if(this.search_block_form.value=='Search'){ alert('Please enter a search'); return false; }";

    // Alternative (HTML5) placeholder attribute instead of using the javascript
    $form['search_block_form']['#attributes']['placeholder'] = t('Search');
} 

function mdta_preprocess_page(&$variables) {
	//Remove secondary menu block if tertiary menu block is on the page
	if(!empty($variables['page']['secondary_menu']['menu_block_2']) && !empty($variables['page']['secondary_menu']['menu_block_3'])) {
		unset($variables['page']['secondary_menu']['menu_block_2']);
	}
}