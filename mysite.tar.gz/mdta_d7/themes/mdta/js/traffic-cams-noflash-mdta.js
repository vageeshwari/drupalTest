/* SWFObject v2.1 <http://code.google.com/p/swfobject/>
  Copyright (c) 2007-2008 Geoff Stearns, Michael Williams, and Bobby van der Sluis
  This software is released under the MIT License <http://www.opensource.org/licenses/mit-license.php>
*/
var swfobject=function(){var b="undefined",Q="object",n="Shockwave Flash",p="ShockwaveFlash.ShockwaveFlash",P="application/x-shockwave-flash",m="SWFObjectExprInst",j=window,K=document,T=navigator,o=[],N=[],i=[],d=[],J,Z=null,M=null,l=null,e=false,A=false;var h=function(){var v=typeof K.getElementById!=b&&typeof K.getElementsByTagName!=b&&typeof K.createElement!=b,AC=[0,0,0],x=null;if(typeof T.plugins!=b&&typeof T.plugins[n]==Q){x=T.plugins[n].description;if(x&&!(typeof T.mimeTypes!=b&&T.mimeTypes[P]&&!T.mimeTypes[P].enabledPlugin)){x=x.replace(/^.*\s+(\S+\s+\S+$)/,"$1");AC[0]=parseInt(x.replace(/^(.*)\..*$/,"$1"),10);AC[1]=parseInt(x.replace(/^.*\.(.*)\s.*$/,"$1"),10);AC[2]=/r/.test(x)?parseInt(x.replace(/^.*r(.*)$/,"$1"),10):0}}else{if(typeof j.ActiveXObject!=b){var y=null,AB=false;try{y=new ActiveXObject(p+".7")}catch(t){try{y=new ActiveXObject(p+".6");AC=[6,0,21];y.AllowScriptAccess="always"}catch(t){if(AC[0]==6){AB=true}}if(!AB){try{y=new ActiveXObject(p)}catch(t){}}}if(!AB&&y){try{x=y.GetVariable("$version");if(x){x=x.split(" ")[1].split(",");AC=[parseInt(x[0],10),parseInt(x[1],10),parseInt(x[2],10)]}}catch(t){}}}}var AD=T.userAgent.toLowerCase(),r=T.platform.toLowerCase(),AA=/webkit/.test(AD)?parseFloat(AD.replace(/^.*webkit\/(\d+(\.\d+)?).*$/,"$1")):false,q=false,z=r?/win/.test(r):/win/.test(AD),w=r?/mac/.test(r):/mac/.test(AD);/*@cc_on q=true;@if(@_win32)z=true;@elif(@_mac)w=true;@end@*/return{w3cdom:v,pv:AC,webkit:AA,ie:q,win:z,mac:w}}();var L=function(){if(!h.w3cdom){return }f(H);if(h.ie&&h.win){try{K.write("<script id=__ie_ondomload defer=true src=//:><\/script>");J=C("__ie_ondomload");if(J){I(J,"onreadystatechange",S)}}catch(q){}}if(h.webkit&&typeof K.readyState!=b){Z=setInterval(function(){if(/loaded|complete/.test(K.readyState)){E()}},10)}if(typeof K.addEventListener!=b){K.addEventListener("DOMContentLoaded",E,null)}R(E)}();function S(){if(J.readyState=="complete"){J.parentNode.removeChild(J);E()}}function E(){if(e){return }if(h.ie&&h.win){var v=a("span");try{var u=K.getElementsByTagName("body")[0].appendChild(v);u.parentNode.removeChild(u)}catch(w){return }}e=true;if(Z){clearInterval(Z);Z=null}var q=o.length;for(var r=0;r<q;r++){o[r]()}}function f(q){if(e){q()}else{o[o.length]=q}}function R(r){if(typeof j.addEventListener!=b){j.addEventListener("load",r,false)}else{if(typeof K.addEventListener!=b){K.addEventListener("load",r,false)}else{if(typeof j.attachEvent!=b){I(j,"onload",r)}else{if(typeof j.onload=="function"){var q=j.onload;j.onload=function(){q();r()}}else{j.onload=r}}}}}function H(){var t=N.length;for(var q=0;q<t;q++){var u=N[q].id;if(h.pv[0]>0){var r=C(u);if(r){N[q].width=r.getAttribute("width")?r.getAttribute("width"):"0";N[q].height=r.getAttribute("height")?r.getAttribute("height"):"0";if(c(N[q].swfVersion)){if(h.webkit&&h.webkit<312){Y(r)}W(u,true)}else{if(N[q].expressInstall&&!A&&c("6.0.65")&&(h.win||h.mac)){k(N[q])}else{O(r)}}}}else{W(u,true)}}}function Y(t){var q=t.getElementsByTagName(Q)[0];if(q){var w=a("embed"),y=q.attributes;if(y){var v=y.length;for(var u=0;u<v;u++){if(y[u].nodeName=="DATA"){w.setAttribute("src",y[u].nodeValue)}else{w.setAttribute(y[u].nodeName,y[u].nodeValue)}}}var x=q.childNodes;if(x){var z=x.length;for(var r=0;r<z;r++){if(x[r].nodeType==1&&x[r].nodeName=="PARAM"){w.setAttribute(x[r].getAttribute("name"),x[r].getAttribute("value"))}}}t.parentNode.replaceChild(w,t)}}function k(w){A=true;var u=C(w.id);if(u){if(w.altContentId){var y=C(w.altContentId);if(y){M=y;l=w.altContentId}}else{M=G(u)}if(!(/%$/.test(w.width))&&parseInt(w.width,10)<310){w.width="310"}if(!(/%$/.test(w.height))&&parseInt(w.height,10)<137){w.height="137"}K.title=K.title.slice(0,47)+" - Flash Player Installation";var z=h.ie&&h.win?"ActiveX":"PlugIn",q=K.title,r="MMredirectURL="+j.location+"&MMplayerType="+z+"&MMdoctitle="+q,x=w.id;if(h.ie&&h.win&&u.readyState!=4){var t=a("div");x+="SWFObjectNew";t.setAttribute("id",x);u.parentNode.insertBefore(t,u);u.style.display="none";var v=function(){u.parentNode.removeChild(u)};I(j,"onload",v)}U({data:w.expressInstall,id:m,width:w.width,height:w.height},{flashvars:r},x)}}function O(t){if(h.ie&&h.win&&t.readyState!=4){var r=a("div");t.parentNode.insertBefore(r,t);r.parentNode.replaceChild(G(t),r);t.style.display="none";var q=function(){t.parentNode.removeChild(t)};I(j,"onload",q)}else{t.parentNode.replaceChild(G(t),t)}}function G(v){var u=a("div");if(h.win&&h.ie){u.innerHTML=v.innerHTML}else{var r=v.getElementsByTagName(Q)[0];if(r){var w=r.childNodes;if(w){var q=w.length;for(var t=0;t<q;t++){if(!(w[t].nodeType==1&&w[t].nodeName=="PARAM")&&!(w[t].nodeType==8)){u.appendChild(w[t].cloneNode(true))}}}}}return u}function U(AG,AE,t){var q,v=C(t);if(v){if(typeof AG.id==b){AG.id=t}if(h.ie&&h.win){var AF="";for(var AB in AG){if(AG[AB]!=Object.prototype[AB]){if(AB.toLowerCase()=="data"){AE.movie=AG[AB]}else{if(AB.toLowerCase()=="styleclass"){AF+=' class="'+AG[AB]+'"'}else{if(AB.toLowerCase()!="classid"){AF+=" "+AB+'="'+AG[AB]+'"'}}}}}var AD="";for(var AA in AE){if(AE[AA]!=Object.prototype[AA]){AD+='<param name="'+AA+'" value="'+AE[AA]+'" />'}}v.outerHTML='<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"'+AF+">"+AD+"</object>";i[i.length]=AG.id;q=C(AG.id)}else{if(h.webkit&&h.webkit<312){var AC=a("embed");AC.setAttribute("type",P);for(var z in AG){if(AG[z]!=Object.prototype[z]){if(z.toLowerCase()=="data"){AC.setAttribute("src",AG[z])}else{if(z.toLowerCase()=="styleclass"){AC.setAttribute("class",AG[z])}else{if(z.toLowerCase()!="classid"){AC.setAttribute(z,AG[z])}}}}}for(var y in AE){if(AE[y]!=Object.prototype[y]){if(y.toLowerCase()!="movie"){AC.setAttribute(y,AE[y])}}}v.parentNode.replaceChild(AC,v);q=AC}else{var u=a(Q);u.setAttribute("type",P);for(var x in AG){if(AG[x]!=Object.prototype[x]){if(x.toLowerCase()=="styleclass"){u.setAttribute("class",AG[x])}else{if(x.toLowerCase()!="classid"){u.setAttribute(x,AG[x])}}}}for(var w in AE){if(AE[w]!=Object.prototype[w]&&w.toLowerCase()!="movie"){F(u,w,AE[w])}}v.parentNode.replaceChild(u,v);q=u}}}return q}function F(t,q,r){var u=a("param");u.setAttribute("name",q);u.setAttribute("value",r);t.appendChild(u)}function X(r){var q=C(r);if(q&&(q.nodeName=="OBJECT"||q.nodeName=="EMBED")){if(h.ie&&h.win){if(q.readyState==4){B(r)}else{j.attachEvent("onload",function(){B(r)})}}else{q.parentNode.removeChild(q)}}}function B(t){var r=C(t);if(r){for(var q in r){if(typeof r[q]=="function"){r[q]=null}}r.parentNode.removeChild(r)}}function C(t){var q=null;try{q=K.getElementById(t)}catch(r){}return q}function a(q){return K.createElement(q)}function I(t,q,r){t.attachEvent(q,r);d[d.length]=[t,q,r]}function c(t){var r=h.pv,q=t.split(".");q[0]=parseInt(q[0],10);q[1]=parseInt(q[1],10)||0;q[2]=parseInt(q[2],10)||0;return(r[0]>q[0]||(r[0]==q[0]&&r[1]>q[1])||(r[0]==q[0]&&r[1]==q[1]&&r[2]>=q[2]))?true:false}function V(v,r){if(h.ie&&h.mac){return }var u=K.getElementsByTagName("head")[0],t=a("style");t.setAttribute("type","text/css");t.setAttribute("media","screen");if(!(h.ie&&h.win)&&typeof K.createTextNode!=b){t.appendChild(K.createTextNode(v+" {"+r+"}"))}u.appendChild(t);if(h.ie&&h.win&&typeof K.styleSheets!=b&&K.styleSheets.length>0){var q=K.styleSheets[K.styleSheets.length-1];if(typeof q.addRule==Q){q.addRule(v,r)}}}function W(t,q){var r=q?"visible":"hidden";if(e&&C(t)){C(t).style.visibility=r}else{V("#"+t,"visibility:"+r)}}function g(s){var r=/[\\\"<>\.;]/;var q=r.exec(s)!=null;return q?encodeURIComponent(s):s}var D=function(){if(h.ie&&h.win){window.attachEvent("onunload",function(){var w=d.length;for(var v=0;v<w;v++){d[v][0].detachEvent(d[v][1],d[v][2])}var t=i.length;for(var u=0;u<t;u++){X(i[u])}for(var r in h){h[r]=null}h=null;for(var q in swfobject){swfobject[q]=null}swfobject=null})}}();return{registerObject:function(u,q,t){if(!h.w3cdom||!u||!q){return }var r={};r.id=u;r.swfVersion=q;r.expressInstall=t?t:false;N[N.length]=r;W(u,false)},getObjectById:function(v){var q=null;if(h.w3cdom){var t=C(v);if(t){var u=t.getElementsByTagName(Q)[0];if(!u||(u&&typeof t.SetVariable!=b)){q=t}else{if(typeof u.SetVariable!=b){q=u}}}}return q},embedSWF:function(x,AE,AB,AD,q,w,r,z,AC){if(!h.w3cdom||!x||!AE||!AB||!AD||!q){return }AB+="";AD+="";if(c(q)){W(AE,false);var AA={};if(AC&&typeof AC===Q){for(var v in AC){if(AC[v]!=Object.prototype[v]){AA[v]=AC[v]}}}AA.data=x;AA.width=AB;AA.height=AD;var y={};if(z&&typeof z===Q){for(var u in z){if(z[u]!=Object.prototype[u]){y[u]=z[u]}}}if(r&&typeof r===Q){for(var t in r){if(r[t]!=Object.prototype[t]){if(typeof y.flashvars!=b){y.flashvars+="&"+t+"="+r[t]}else{y.flashvars=t+"="+r[t]}}}}f(function(){U(AA,y,AE);if(AA.id==AE){W(AE,true)}})}else{if(w&&!A&&c("6.0.65")&&(h.win||h.mac)){A=true;W(AE,false);f(function(){var AF={};AF.id=AF.altContentId=AE;AF.width=AB;AF.height=AD;AF.expressInstall=w;k(AF)})}}},getFlashPlayerVersion:function(){return{major:h.pv[0],minor:h.pv[1],release:h.pv[2]}},hasFlashPlayerVersion:c,createSWF:function(t,r,q){if(h.w3cdom){return U(t,r,q)}else{return undefined}},removeSWF:function(q){if(h.w3cdom){X(q)}},createCSS:function(r,q){if(h.w3cdom){V(r,q)}},addDomLoadEvent:f,addLoadEvent:R,getQueryParamValue:function(v){var u=K.location.search||K.location.hash;if(v==null){return g(u)}if(u){var t=u.substring(1).split("&");for(var r=0;r<t.length;r++){if(t[r].substring(0,t[r].indexOf("="))==v){return g(t[r].substring((t[r].indexOf("=")+1)))}}}return""},expressInstallCallback:function(){if(A&&M){var q=C(m);if(q){q.parentNode.replaceChild(M,q);if(l){W(l,true);if(h.ie&&h.win){M.style.display="block"}}M=null;l=null;A=false}}}}}();

/*==================================
 * PlayerView
 * - Creation and disposing of Flash player
 *   for traffic camera video feeds.
 *==================================*/
var PlayerView = (function(){

    function deletePlayer(theWrapper, thePlaceholder, thePlayerId) { 
        swfobject.removeSWF(thePlayerId);
        var tmp=document.getElementById(theWrapper);
        if (tmp) { tmp.innerHTML = "<div id=" + thePlaceholder + "></div>"; }
    }

    function createPlayer(thePlaceholder, thePlayerId, theFile, theIP) {
            var flashvars = {
                  file:theFile, 
                  streamer:"rtmp://" + theIP + "/rtplive",
                  autostart:"true",
                  bufferlength:"4",
                  type:"video",
                  displayclick:"stop",
                  controlbar:"none",
                  stretching:"exactfit"
            }
            var params = {
                    allowfullscreen:"true", 
                    allowscriptaccess:"always"
            }
            var attributes = {
                    id:thePlayerId,  
                    name:thePlayerId
            }
            swfobject.embedSWF("../themes/mdta/js/player.swf", thePlaceholder, "480", "340", "9.0.115", false, flashvars, params, attributes);
    }

    function initPlayer(stream) {
        var streamAttr = stream.split("/");
        deletePlayer('cam-wrap', 'cam-placeholder', 'player1'); 
        createPlayer('cam-placeholder', 'player1', streamAttr[4], streamAttr[2]);
    }

    return {init:initPlayer}

})();

/*==================================
 * CameraListView
 * - Creates and maintains menu items.
 * - Filters menu items.
 *==================================*/
var CameraListView = (function(){


    /*
        Camera Data Example
        {
        "name":"Traffic Cam Name/Location",
        "keywords" : "",
        "rtmp":"rtmp://...",
        "rtsp":"rtsp://...",
        "latitude":0.00,
        "longitude":0.00,
        "id":"camera-1A",
        "region":"Baltimore"
        }

    //*/

    var menuItems = [];

    var childWindows = []; //Store popup windows to avoid reloading same cam
    var currentCamera = false;

    /*----------------------------------
     * init
     *  Initialize menu
      ----------------------------------*/
    function init(){

      generateMenu(CameraData);
      DataMembers.data = CameraData; // should be in controller
      DataMembers.elements = menuItems; // not actually maintained by Model

    }

    function initNoFlash(){

      $("#traffic-cams").addClass("noflash");
      generateMenuNoFlash(CameraData);
      DataMembers.data = CameraData; // should be in controller
      DataMembers.elements = menuItems; // not actually maintained by Model

    }

    /*----------------------------------
     * getElementData
     *  @param element : DOM object
     *  Generates and stores dom link and html for
     *  camera.
      ----------------------------------*/
    function getElementData(element){
      return DataMembers.getElementData(element);
    }

    /*----------------------------------
     * createListItem
     *  @param item : JSON/CameraData item
     *  Generates and stores single dom link and html for
     *  camera.
      ----------------------------------*/
    function createListItem(item){
      var t_li = document.createElement("li");
      var t_a = document.createElement("a");
      var t_n = document.createTextNode(item.name);

      t_a.href = "#"+item.id;
      //t_a.id = item.id;
      t_a.rel = item.id;


      // Bind onclick to each traffic camera menu/list item
      t_a.onclick = function(event){

        // IE reports event targets differently
        event = event ? event : window.event;
        if (typeof event.target == 'undefined') {
          var target = event.srcElement;
        }else{
          var target = event.target;
        }
        CameraController.elemOnClick(target); // Run click action in controller
      }

      t_a.appendChild(t_n); // add text node to <a> link
      t_li.appendChild(t_a); // add <a> link to <li>
      $("#filter-results").append(t_li); // add <li> to results <ul>
      menuItems.push(t_a); // store a reference to the link for future use

    }

    /*----------------------------------
     * getMenuItem
     *  @param id : string
     *  Iterates through stored menu items
     *  returns <a> element matching camera id.
      ----------------------------------*/
    function getMenuItem(id){
      for(var i=0;i<+menuItems.length;i++){
        if(menuItems[i].rel == id)
          return menuItems[i];
      }
      return false;
    }

    /*----------------------------------
     * generateMenu
     *  @param dataset : JSON array / CameraData
     *  Iterates through camera JSON data
     *  generates menu item for each camera.
      ----------------------------------*/
    function generateMenu(dataset){
      $("#filter-results").html("");
      for(var i=0; i<dataset.length;i++){
        createListItem(dataset[i]);
      }
    }


    /*----------------------------------
     * generateMenuNoFlash
     *  @param dataset : JSON array / CameraData
     *  Iterates through camera JSON data
     *  generates menu item for each camera.
      ----------------------------------*/
    function generateMenuNoFlash(dataset){

      for(var i=0; i<dataset.length;i++){
        var itemHtml = '<li><a href=' + dataset[i].rtmp + ' target="_blank">' + dataset[i].name + '</a></li>';
        $("#filter-results").append(itemHtml); // add <li> to results <ul>
      }

    }

    /*----------------------------------
     * updateMenu
     *  @param dataset : array / CameraData
     *  Iterates through camera data
     *  hides and shows menu items in current dataset
      ----------------------------------*/
    function updateMenu(dataset){
      $("#filter-results li").addClass("hidden");
      for(var i=0; i<dataset.length;i++){
        $('#filter-results li>a[rel='+dataset[i].id+']').parent().removeClass("hidden");
      }
    }

    /*----------------------------------
     * getMenuItem
     *  @param id : string
     *  Iterates through stored menu items
     *  returns <a> element matching camera id.
      ----------------------------------*/
    function filterMenu(terms){
      updateMenu($.grep( CameraData , function( n, i ) {
        return (n.name).toUpperCase().indexOf(terms.toUpperCase()) >= 0;
      }));
    }

    /*----------------------------------
     * clearActive
     *  Iterates through stored menu items
     *  removes active class
      ----------------------------------*/
      function clearActive(){
        for(var i=0; i<menuItems.length;i++){
          $(menuItems[i]).removeClass("active");
        }
      }

    /*----------------------------------
     * menuScrollTo
     *  @param element : <a> DOM object
     *  Scroll selected menu item into view
      ----------------------------------*/
    function menuScrollTo(element){
      if(element.parentNode.parentNode){
        $(element.parentNode.parentNode).animate({
            scrollTop: element.offsetTop - element.parentNode.parentNode.offsetTop 
          }, 500);
      }
        return false;
    }

    /*----------------------------------
     * "public"
      ----------------------------------*/
    return {
        init:init,
        initNoFlash:initNoFlash,
        filterMenu:filterMenu,
        getMenuItem:getMenuItem,
        menuScrollTo:menuScrollTo,
        clearActive:clearActive
      }

})();

/*==================================
 * GMapView
 * - Creation and updating of Google Map
 * - Creates map markers and events
 *==================================*/
var GMapView = (function(){

    var map = false;
    var mapOptions = {
        zoom: 12,
        center: new google.maps.LatLng(39.263535, -76.566994),
        disableDefaultUI: true
      }

    /*----------------------------------
     * init
     *  Initialize Google Map API
      ----------------------------------*/
    function init() {
      map = new google.maps.Map(document.getElementById('map-output'),mapOptions);
    }

    /*----------------------------------
     * setMarkers
     *  @param cameras : array
     *  Iterates through camera items
     *  creates map marker for each camera
     *  binds marker click event.
      ----------------------------------*/
    function setMarkers(cameras) {
      // configuration for marker
      var image = {
        url: '../themes/mdta/images/cam-marker.png',
        size: new google.maps.Size(23, 31),
        origin: new google.maps.Point(0,0),
        anchor: new google.maps.Point(20, 15)
      };

      // clickable region for map marker
      var shape = {
          coords: [1, 1, 1, 20, 25, 20, 25 , 1],
          type: 'poly'
      };

      // iterate through cameras and set marker
      for (var i = 0; i < cameras.length; i++) {
        var camera = cameras[i];
        var myLatLng = new google.maps.LatLng(camera["latitude"], camera["longitude"]);
        var marker = new google.maps.Marker({
            position: myLatLng,
            map: map,
            icon: image,
            shape: shape,
            title: camera["name"],
            zIndex: i+1
        });
        
        // Use closure to bind events for each camera. Non-closed function will not specific id.
        google.maps.event.addListener(marker,'click', (function(marker, camera){ 
            return function() {
                CameraController.loadCamera(camera.id); // Controller update views
            };
        })(marker,camera)); 

      }
    }

    /*----------------------------------
     * centerMap
     *  @param latitude : float
     *  @param longitude : float
     *  Centers Map
     *  propogates center map to google map
      ----------------------------------*/
    function centerMap(latitude,longitude){
      //map.setCenter(new google.maps.LatLng(latitude, longitude));
      map.panTo(new google.maps.LatLng(latitude, longitude));
    }

    //google.maps.event.addDomListener(window, 'load', init);

    /*----------------------------------
     * "public"
      ----------------------------------*/
    return {
      init:init,
      setMarkers:setMarkers,
      centerMap:centerMap
    }

})();

/*==================================
 * CameraController
 * - Manages loading views
 * - Binds Data/Model
 * - Binds interaction events
 *==================================*/
var CameraController = (function(){

    var DATA_URL = 'app/js/traffic-cam-data.js';
    var DEFAULT_CAM = "rtmp://170.93.143.140:1935/rtplive/0f019fd7443a0032004606363d235daa";
    var cameraData = false;

    var cameraListView = CameraListView;
    var playerView = PlayerView;
    var gmapView = GMapView;

    var isMobile;

    /*----------------------------------
     * init
     *  Initialize Camera Controller
     *  Initializes Views
      ----------------------------------*/
    function init(){

      window.onhashchange = function(event){
        var evt = window.event || event;
        window.event.returnValue = false;
        window.event.cancelBubble = true;
        if(event.preventDefault) event.preventDefault();
        return false;
      }//*/

      jQuery("#cam-filter").bind('change, keyup', function(){
        
        CameraListView.filterMenu($(this).val());
      });


      //Init flash-based application
     

        gmapView.init();
        cameraListView.init();

        loadData();

        if(location.hash.indexOf("camera")==1){
          playerView.init(DataMembers.findElement(location.hash.split('#')[1]).rtmp);

          loadCamera(location.hash.split('#')[1]);

        }else{
          $("#filter-results a").first().click();
        }
		if (swfobject.hasFlashPlayerVersion("9.0.18")) {
      }else {
        // Init no-flash application
        cameraListView.initNoFlash();
        
      }


    }

    /*----------------------------------
     * loadData
     *  Ajax get JSON data
     *  on data load, update views.
      ----------------------------------*/
    function loadData(){
    /* $.ajax( DATA_URL )
      .done(function(data) {
        cameraData = jQuery.parseJSON(data);
        console.log("Camera Data ", cameraData);
        gmapView.setMarkers(cameraData);
      })
      .fail(function() {
        //displayError();
        console.log("error loading camera data");
      });
      //*/

      gmapView.setMarkers(CameraData);
      DataMembers.data = CameraData;
    }

  
    /*----------------------------------
     * elemOnClick
     *  @param element : <a>element
     *  Initializes Views
      ----------------------------------*/
    function elemOnClick(element){
      //$("#filter-results a.active").removeClass("active");
      CameraListView.clearActive();

        $(element).addClass("active");
        var camera = DataMembers.findElement(element.rel);
        PlayerView.init(camera.rtmp);
        gmapView.centerMap(camera.latitude, camera.longitude);

        if(history.pushState) {
          history.pushState(null, null, "#" + camera.id);
        } else {
          //location.hash = "#" + element.id;
        }

        return false;

    }

    /*----------------------------------
     * loadCamera
     *  @param id : string
     *  Finds associated camera elements
     *  propagates camera load.
     *  Sets menu item active.
     *  Used by google maps markers
      ----------------------------------*/
    function loadCamera(id){
      var camera = CameraListView.getMenuItem(id);
      CameraListView.menuScrollTo(camera);//scroll camera in menu list into view
      elemOnClick(camera);
      $('#filter-results a[href=#' + id + ']').addClass("active");
    }


    /*-----------UNUSED-----------------
     * stopEvent
     *  @param evt : Event
     *  Cross-browser stop event propogation
     *  Was to used to stop browser from jumping to page anchors.
      ----------------------------------*/
    function stopEvent(evt){
      evt = window.event || evt;
      if (evt.preventDefault) {
          evt.preventDefault();
      } else {
          evt.returnValue = false;
          //evt.cancelBubble = true;
      }

      if ( evt.stopPropagation ) evt.stopPropagation();

      return false;
    }

    /*----------------------------------
     * "public"
      ----------------------------------*/
    return {
      init:init,
      cameraData:cameraData,
      elemOnClick:elemOnClick,
      loadCamera:loadCamera,
      stopEvent:stopEvent
    }

})();

/*==================================
 * DataMembers
 * - Stores JSON/CameraData
 * - Stores Menu Elements
 *==================================*/
var DataMembers = (function(){

  var _data = [];
  var _elements = [];

  /*----------------------------------
   * init
   * @param data : JSON/CameraData
   * @param objects : <a>array
   *  set object references
    ----------------------------------*/
  function init(data, objects){
    _data = data;
    _elements = objects;
  }

  /*----------------------------------
   * getElementData
   * @param element : <a> DOM object
   *  returns CameraData associated with menu <a> element
    ----------------------------------*/
  function getElementData(element){
    return _data[_elements.indexOf(element)];
  }

  /*----------------------------------
   * findElement
   * @param id : string
   *  retuns CameraData associated with camera ID
    ----------------------------------*/
  function findElement(id){
    for(var i=0;i<CameraData.length;i++){
      if(CameraData[i].id == id)
        return CameraData[i];
    }
    return false;
  }

/*  function findObj(id){
    console.log("findObj", _elements);
    for(var i=0;i<+_elements.length;i++){
      if(_elements[i].id == id)
        return _elements[i];
    }
    return false;
  }*/

  /*----------------------------------
   * "public"
    ----------------------------------*/
  return {
    init:init,
    elements:_elements,
    data:_data,
    getElementData:getElementData,
    findElement:findElement
    }

})();

//TMP JSON CameraData
var CameraData = [
{"name":"I-95 N. OF MD 279", "keywords":"i95, north","id":"camera-1","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/0f019fd7443a0032004606363d235daa/playlist.m3u8","rtsp":"","latitude":39.6405,"longitude":-75.80136},
{"name":"I-95 N. OF TYDINGS BR", "keywords":"i95, north","id":"camera-10","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/7d0095e200e40039004606363d235daa/playlist.m3u8","rtsp":"","latitude":39.584896,"longitude":-76.09684},
{"name":"I-95 N. OF MD 22", "keywords":"i95, north","id":"camera-15","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/4d00a5a100e50039004606363d235daa/playlist.m3u8","rtsp":"","latitude":39.527466,"longitude":-76.188652},
{"name":"I-95 AT MD 24", "keywords":"i95, vietnam veterans memorial highway","id":"camera-19","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/d801490d01350160004806363d235daa/playlist.m3u8","rtsp":"","latitude":39.454597,"longitude":-76.314156},
{"name":"I-95 N. OF MD 152", "keywords":"i95, north, mountain road","id":"camera-21","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/0901cb3400e80039004606363d235daa/playlist.m3u8","rtsp":"","latitude":39.441742,"longitude":-76.348061},
{"name":"I-95 N OF MD 43 (Whitemarsh Blvd)", "keywords":"i95, north","id":"camera-22","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/f101757700e30039004606363d235daa/playlist.m3u8","rtsp":"","latitude":39.38173,"longitude":-76.4459},
{"name":"I-95 AT MD 43E", "keywords":"i95","id":"camera-23","Region":"Baltimore","rtmp":"http://170.93.143.138:1935/rtplive/d200cf40000100f20053fa36c4235c0a/playlist.m3u8","rtsp":"","latitude":39.379234,"longitude":-76.452332},
{"name":"I-95 N. OF I-695 EX 64", "keywords":"i95, north, i695","id":"camera-24","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/36008da300e40039004606363d235daa/playlist.m3u8","rtsp":"","latitude":39.352726,"longitude":-76.493591},
{"name":"I-695 E OF I-95 ON I/L", "keywords":"i95, east, i695","id":"camera-25","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/d6009a3500e50039004606363d235daa/playlist.m3u8","rtsp":"","latitude":39.347252,"longitude":-76.495171},
{"name":"I-95 S OF I-695", "keywords":"i95, south, i695","id":"camera-26","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/2f009e8a00e50039004606363d235daa/playlist.m3u8","rtsp":"","latitude":39.348465,"longitude":-76.501785},
{"name":"I-895 S OF I-95 SPLIT", "keywords":"i95, south, i895","id":"camera-28","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/5f00c39300e70039004606363d235daa/playlist.m3u8","rtsp":"","latitude":39.322884,"longitude":-76.529633},
{"name":"I-895 S OF O'DONNELL ST", "keywords":"i895, south","id":"camera-35","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/b8007791019100e300441a366e230214/playlist.m3u8","rtsp":"","latitude":39.280869,"longitude":-76.55352},
{"name":"I-95 AT FMT VENT BLDG", "keywords":"i95, tunnel, fort, mchenry","id":"camera-39","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/47017d19019200e300441a366e230214/playlist.m3u8","rtsp":"","latitude":39.263535,"longitude":-76.566994},
{"name":"I-95 N. OF ODONNELL ST", "keywords":"","id":"camera-41","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/8301fd37011a004b004606363d235daa/playlist.m3u8","rtsp":"","latitude":39.284472,"longitude":-76.546548},
{"name":"I-895 AT POTEE ST", "keywords":"i895","id":"camera-48","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/fa011d4100680049004806363d235daa/playlist.m3u8","rtsp":"","latitude":39.23914,"longitude":-76.6148},
{"name":"I-695 N. OF FSK BRIDGE ON I/L ", "keywords":"i695 francis scott key","id":"camera-53","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/4a014528c47701b8004606363d235daa/playlist.m3u8","rtsp":"","latitude":39.227219,"longitude":-76.515074},
{"name":"US 301 N. OF TOLL PLAZA ", "keywords":"","id":"camera-61","Region":"Southern Maryland","rtmp":"http://170.93.143.138:1935/rtplive/f7ff8198c47801b8004606363d235daa/playlist.m3u8","rtsp":"","latitude":38.365456,"longitude":-76.968418},
{"name":"ICC MD 200 WB, N/METRO ACCESS RD, MM 2.9", "keywords":"","id":"camera-202","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/2a012b0800ae0059004d06363d235daa/playlist.m3u8","rtsp":"","latitude":39.137367,"longitude":-77.16239},
{"name":"ICC MD 200 EB, REDLAND RD, MM 3.9 ", "keywords":"","id":"camera-203","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/7b011318000d0053004d06363d235daa/playlist.m3u8","rtsp":"","latitude":39.134923,"longitude":-77.145709},
{"name":"ICC MD 200 WB, OVERHILL RD, MM 4.3", "keywords":"","id":"camera-204","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/d60032ad00ae0059004d06363d235daa/playlist.m3u8","rtsp":"","latitude":39.138649,"longitude":-77.141361},
{"name":"ICC MD 200 EB, DECKOVER APPROACH, MM 4.4 ", "keywords":"","id":"camera-205","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/550255680555004e004d06363d235daa/playlist.m3u8","rtsp":"","latitude":39.138199,"longitude":-77.135096},
{"name":"ICC MD 200 EB, DECKOVER INTERIOR, MM 4.5 ", "keywords":"","id":"camera-206","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/a70150c00554004e004d06363d235daa/playlist.m3u8","rtsp":"","latitude":39.138108,"longitude":-77.134656},
{"name":"ICC MD 200 WB, DECKOVER INTERIOR, MM 4.6", "keywords":"","id":"camera-207","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/b000389a059e004b004d06363d235daa/playlist.m3u8","rtsp":"","latitude":39.137791,"longitude":-77.13369},
{"name":"ICC MD 200 WB, DECKOVER APPROACH, MM 4.7", "keywords":"","id":"camera-208","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/7f014af00502004e004d06363d235daa/playlist.m3u8","rtsp":"","latitude":39.137542,"longitude":-77.1331},
{"name":"ICC MD 200 WB, NEEDWOOD RD, MM 5.1", "keywords":"","id":"camera-209","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/bc001dc100950059004d06363d235daa/playlist.m3u8","rtsp":"","latitude":39.133572,"longitude":-77.125933},
{"name":"ICC MD 200 EB, WEST OF MUNCASTER MILL ROAD (RT 115)", "keywords":"","id":"camera-210","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/da0039a900af0059004d06363d235daa/playlist.m3u8","rtsp":"","latitude":39.127663,"longitude":-77.121191},
{"name":"ICC MD 200 WB, E OF MUNCASTER, MM 6.5", "keywords":"","id":"camera-211","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/800026950585004b004d06363d235daa/playlist.m3u8","rtsp":"","latitude":39.126515,"longitude":-77.104733},
{"name":"ICC MD 200 WB, WEST OF MD 97, MM 8.0", "keywords":"","id":"camera-212","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/8201404900b00059004d06363d235daa/playlist.m3u8","rtsp":"","latitude":39.119357,"longitude":-77.0804},
{"name":"ICC MD 200 EB E OF 97 MP 8.7 ", "keywords":"","id":"camera-213","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/d2005d9a001a00bd004e3336c4235c0a/playlist.m3u8","rtsp":"","latitude":39.117242,"longitude":-77.068748},
{"name":"ICC MD 200 EB W OF 182 MP 10.4", "keywords":"","id":"camera-215","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/d7006b8f001c00bd004e3336c4235c0a/playlist.m3u8","rtsp":"","latitude":39.100825,"longitude":-77.044973},
{"name":"ICC MD 200 WB E OF 182 MP 11.1", "keywords":"","id":"camera-216","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/f2009c74002100bd004e3336c4235c0a/playlist.m3u8","rtsp":"","latitude":39.098294,"longitude":-77.037935},
{"name":"ICC MD 200 EB AT BONIFANT MP 11.8", "keywords":"","id":"camera-217","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/9f00a319002200bd004e3336c4235c0a/playlist.m3u8","rtsp":"","latitude":39.094364,"longitude":-77.030468},
{"name":"ICC MD 200 EB W OF 650 MP 12.9", "keywords":"","id":"camera-218","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/2e00aaa1002200bd004e3336c4235c0a/playlist.m3u8","rtsp":"","latitude":39.088369,"longitude":-77.003517},
{"name":"ICC MD 200 WB E OF 650 MP 13.9 ", "keywords":"","id":"camera-219","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/a800b113002300bd004e3336c4235c0a/playlist.m3u8","rtsp":"","latitude":39.089301,"longitude":-76.995106},
{"name":"ICC MD 200 EB W OF US 29 MP 15.8", "keywords":"","id":"camera-221","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/6c017914001e00bd004e3336c4235c0a/playlist.m3u8","rtsp":"","latitude":39.079141,"longitude":-76.955323},
{"name":"ICC MD 200 EB E OF US 29 MP 16.2", "keywords":"","id":"camera-222","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/f6ff8097001e00bd004e3336c4235c0a/playlist.m3u8","rtsp":"","latitude":39.074827,"longitude":-76.945946},
{"name":"ICC MD 200 WB AT BRIGGS MP 17.1", "keywords":"","id":"camera-223","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/aa00cb3a00f300ae004e3336c4235c0a/playlist.m3u8","rtsp":"","latitude":39.073544,"longitude":-76.939659},
{"name":"ICC MD 200 EB WEST OF I-95 MP 18.1", "keywords":"","id":"camera-224","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/c8008761001f00bd004e3336c4235c0a/playlist.m3u8","rtsp":"","latitude":39.074361,"longitude":-76.914639},
{"name":"ICC MD 200 WB AT I-95 MP 18.6 ", "keywords":"","id":"camera-225","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/7f00d20700f400ae004e3336c4235c0a/playlist.m3u8","rtsp":"","latitude":39.073994,"longitude":-76.906099},
{"name":"US 50 AT SANDY POINT", "keywords":"","id":"camera-991","Region":"Annapolis","rtmp":"http://170.93.143.139:1935/rtplive/7901e75800f700d700437a45351f0214/playlist.m3u8","rtsp":"","latitude":39.017774,"longitude":-76.409541},
{"name":"I-95 AT I-395", "keywords":"","id":"camera-992","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/bb01285801f700d700437a45351f0214/playlist.m3u8","rtsp":"","latitude":39.268005,"longitude":-76.624576},
{"name":"I-97 AT MD-100", "keywords":"","id":"camera-993","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/bb01295800f700d700437a45351f0214/playlist.m3u8","rtsp":"","latitude":39.152623,"longitude":-76.645967},
{"name":"WEATHER STATION - US 50 AT KENT NARROWS", "keywords":"","id":"camera-994","Region":"Eastern Shore","rtmp":"http://170.93.143.139:1935/rtplive/3c0090ba006f00b60050fa36c4235c0a/playlist.m3u8","rtsp":"","latitude":38.971065,"longitude":-76.249227},
{"name":"US 50 AT MD 202", "keywords":"","id":"camera-995","Region":"Washington","rtmp":"http://170.93.143.139:1935/rtplive/6001cd5801f700d700437a45351f0214/playlist.m3u8","rtsp":"","latitude":38.930314,"longitude":-76.897721},
{"name":"I-95 S. NORTH OF JOPPA RD", "keywords":"","id":"camera-21A","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/5601403c00860064004d06363d235daa/playlist.m3u8","rtsp":"","latitude":39.400035,"longitude":-76.428511},
{"name":"I-95 N. NORTH OF KING AVE", "keywords":"","id":"camera-23A","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/f80049ce008d0064004d06363d235daa/playlist.m3u8","rtsp":"","latitude":39.362982,"longitude":-76.471904},
{"name":"I-95 S. GP AT I-695,MP 67.5", "keywords":"","id":"camera-24A","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/65002ee001eb009c0052fa36c4235c0a/playlist.m3u8","rtsp":"","latitude":39.383726,"longitude":-76.443549},
{"name":"I-95N GP AT I-695, MP 63.8", "keywords":"","id":"camera-24B","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/0000309302ce009e0052fa36c4235c0a/playlist.m3u8","rtsp":"","latitude":39.351542,"longitude":-76.493898},
{"name":"I-95N ML AT I-695, MP 63.6", "keywords":"","id":"camera-24C","Region":"Baltimore ","rtmp":"http://170.93.143.139:1935/rtplive/de00376802d0009e0052fa36c4235c0a/playlist.m3u8","rtsp":"","latitude":39.353144,"longitude":-76.492664},
{"name":"I-95SB, MP 62.7 (Hazelwood)", "keywords":"","id":"camera-27A","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/e9003d5100b200a5004e3336c4235c0a/playlist.m3u8","rtsp":"","latitude":39.346277,"longitude":-76.506302},
{"name":"I-95NB, MP 62.0 (North of Chesaco)", "keywords":"","id":"camera-27B","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/5e0044bd00b400a5004e3336c4235c0a/playlist.m3u8","rtsp":"","latitude":39.339108,"longitude":-76.514943},
{"name":"I-95NB, MP 61.4 (South of Chesaco)", "keywords":"","id":"camera-27C","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/7d004bd400b500a5004e3336c4235c0a/playlist.m3u8","rtsp":"","latitude":39.33172,"longitude":-76.520562},
{"name":"I-895 AT MORAVIA RD", "keywords":"","id":"camera-moravia","Region":"Baltimore","rtmp":"http://170.93.143.139:1935/rtplive/7f01597a018d00e300441a366e230214/playlist.m3u8","rtsp":"","latitude":39.312532,"longitude":-76.540418},
{"name":"ICC MD 200 WB AT LONGMEAD MP 9.6", "keywords":"","id":"camera-longmead","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/e70064a7001b00bd004e3336c4235c0a/playlist.m3u8","rtsp":"","latitude":39.107236,"longitude":-77.053632},
{"name":"ICC MD 200 WB, CRABBS BRANCH WAY, MM 2.2", "keywords":"","id":"camera-crabbs","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/c50024ab00ad0059004d06363d235daa/playlist.m3u8","rtsp":"","latitude":39.129827,"longitude":-77.172217},
{"name":"ICC MD 200 EB AT CREEKSIDE MP 14.9 ", "keywords":"","id":"camera-creekside","Region":"MD 200 ICC","rtmp":"http://170.93.143.139:1935/rtplive/7d01722d001d00bd004e3336c4235c0a/playlist.m3u8","rtsp":"","latitude":39.083255,"longitude":-76.968262}
];


jQuery(document).ready(function(){CameraController.init();});