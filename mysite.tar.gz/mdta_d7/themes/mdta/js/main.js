jQuery(document).ready(function(){
	jQuery("#mdgov_secondaryNav nav ul li.menu-item > a").each(function(){ 
		if(jQuery(this).attr("href").split("/").pop().match(/^(none|#)$/))
			jQuery(this).replaceWith("<h2>" + jQuery(this).text() + "</h2>");
	})
	
	jQuery("#mdgov_secondaryNav .menu li .nolink").each(function(){
		jQuery(this).parent().addClass("nolink_parent");
	});
	
	function matchColumHeight(){
		var pageWidth = window.innerWidth;
		if ( pageWidth > 767 ) {
			var divHeight = jQuery("main").outerHeight();
			var secondaryHeight = jQuery("#mdgov_secondaryNav").outerHeight();
			if ( secondaryHeight > divHeight ) {
				divHeight = secondaryHeight;
				jQuery("main").height(divHeight);
			} else {
				jQuery("#mdgov_secondaryNav").height(divHeight);
			}
		} else {
			jQuery("#mdgov_secondaryNav").height("auto");
		}
	}
	jQuery(window).load(function() {
		matchColumHeight();
	});
	jQuery( window ).resize(function() {
		matchColumHeight();
	});	
	
	$('a').not('[href*="mailto:"]').each(function () {
        var isInternalLink = new RegExp('/' + window.location.host + '/');
        if ( ! isInternalLink.test(this.href) ) {
          $(this).attr('target', '_blank');
        }
      });

});